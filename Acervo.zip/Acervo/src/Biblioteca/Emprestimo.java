//Bruno Araujo Orlandi - 832.336
package Biblioteca;

import java.time.LocalDate;

public class Emprestimo {
    
    private int id;
    private int idUsuario;
    private int idLivro;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    private String devolvido;

    //Alt+Insert -> Contrutores...
    public Emprestimo() {
    }

    //Alt+Insert -> Contrutores...
    public Emprestimo(int id, int idUsuario, int idLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, String devolvido) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
    }

    //Alt+Insert -> Getter e Setter...
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(LocalDate dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public String isDevolvido() {
        return devolvido;
    }

    public void setDevolvido(String devolvido) {
        this.devolvido = devolvido;
    }

     //Alt+Insert -> toString...
    @Override
    public String toString() {
        return "Id do Emprestimo: " + id + "\nId do Usuario: " + idUsuario + "\nId do Livro: " + idLivro + "\nData de Emprestimo: " + dataEmprestimo + "\nData de Devolução: " + dataDevolucao + "\nConfirmação de Devolução: " + devolvido + "\n";
    }
    
    
    
    
}
