//Bruno Araujo Orlandi - 832.336
package Biblioteca;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Teste {
    
    public static void main(String[] args) {
        
        List<Usuario> usuarios = new ArrayList <>();
        List<Livro> livros = new ArrayList <>();
        List<Emprestimo> emprestimos = new ArrayList <>();
    
        usuarios.add(new Usuario(832336, "Bruno", "bruno.orlandi@sou.unaerp.edu.br", "123456"));
        usuarios.add(new Usuario(832592, "Silas", "silas.dasilva@sou.unaerp.edu.br", "654321"));
        usuarios.add(new Usuario(335645, "Tigas", "tigas.ventura@sou.unaerp.edu.br", "258025"));
        usuarios.add(new Usuario(875462, "Vinicius", "vinicius.felix@sou.unaerp.edu.br", "bem1234"));
        usuarios.add(new Usuario(895642, "José", "jose.roberto@sou.unaerp.edu.br", "bem4321"));
        
        livros.add(new Livro(01, "O cortiço", "Aluísio Azevedo", "5ª", "Ética", "São Paulo", 1976));
        livros.add(new Livro(02, "Odisseia", "Ruth Rocha", "8ª", "Salamandra", "São Paulo", 2014));
        livros.add(new Livro(03, "Memórias Póstumas de Brás Cubas", "Machado de Assis", "1ª", "Oxford University Press", "Rio de Janeiro", 1881));
        
        emprestimos.add(new Emprestimo(857488,832336,01,LocalDate.of(2020, Month.APRIL,24),LocalDate.of(2020, Month.MARCH,14),"Sim"));
        emprestimos.add(new Emprestimo(849515,875462,03,LocalDate.of(2020, Month.JANUARY,04),LocalDate.of(2020, Month.FEBRUARY,10),"Sim"));
        emprestimos.add(new Emprestimo(464468,895642,03,LocalDate.of(2020, Month.FEBRUARY,10),LocalDate.of(2020, Month.APRIL,02),"Sim"));
        emprestimos.add(new Emprestimo(984651,335645,02,LocalDate.of(2020, Month.MAY,10),LocalDate.now(),"Sim"));
        emprestimos.add(new Emprestimo(849515,832592,01,LocalDate.of(2020, Month.MARCH,17),LocalDate.of(2020, Month.MAY,16),"Sim"));
   
        usuarios.forEach((c) -> {
            System.out.println(c);
        });
        
        livros.forEach((c) -> {
            System.out.println(c);
        });
        
        emprestimos.forEach((c) -> {
            System.out.println(c);
        });
        
    }
 
    
    
}
